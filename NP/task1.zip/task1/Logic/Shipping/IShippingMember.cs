﻿namespace task1.Shipping;

public interface IShippingMember
{
    public void InputFromStr(string[] input);
    public string GetRepresentation();
}