﻿namespace task1.States;

public class ExitState : State
{
    public override bool IsExitState() => true;
}