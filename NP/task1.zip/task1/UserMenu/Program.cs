﻿using task1.Shipping;
using task1.States;
using UserMenu.UserStates;

Menu menu = new(new BaseMenuUserState(), new List<Shipping>(), 
    @"C:\Users\denys\RiderProjects\University\NP\task1\Logic\data\shippings.txt");